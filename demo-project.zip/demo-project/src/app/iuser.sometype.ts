export interface IUser {
   errorMessage:string;
   sucess:string;
}
